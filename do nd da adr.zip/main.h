#ifndef __MAIN_H
#define __MAIN_H

#include <delay.h>
#include <stdio.h>
#include <math.h>
#endif 